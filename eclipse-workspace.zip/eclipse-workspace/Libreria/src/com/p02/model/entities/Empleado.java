package com.p02.model.entities;

public class Empleado {

}
