package com.p02.util.configs;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Configurations {

	/*private DatabaseConfigurations databaseConfigurations;

	public Configurations() {
	}
	
	public DatabaseConfigurations getDatabaseConfigurations() {
		return this.databaseConfigurations;
	}

	public void setDatabaseConfigurations(DatabaseConfigurations databaseConfigurations) {
		this.databaseConfigurations = databaseConfigurations;
	}

	private static Configurations configurations;
	
	public static Configurations getInstance() throws IOException {
		if(configurations != null) {
			return configurations;
		}
		Path envPath = FileUtils.getFolderPath().resolve(".env").toAbsolutePath();		
		
		List<String> configLines = FileUtils.readLines(envPath.toString());
		Map<String, String> configMap = new HashMap<String, String>();
		for(String line : configLines) {
			if(!line.trim().equals("")) {
				String[] args = line.split("=");
				configMap.put(args[0].trim(), args[1].trim());
			}
		}
		
		DatabaseConfigurations dbConfigs = new DatabaseConfigurations();
		dbConfigs.setHost(configMap.get("DB_HOST"));
		dbConfigs.setPort(configMap.get("DB_PORT"));
		dbConfigs.setUsername(configMap.get("DB_USERNAME"));
		dbConfigs.setPassword(configMap.get("DB_PASSWORD"));
		dbConfigs.setDatabase(configMap.get("DB_DATABASE"));
		
		configurations = new Configurations();
		configurations.setDatabaseConfigurations(dbConfigs);
		
		return configurations;
	}*/
	
	//Con esta primera linea forzamos que cargue el driver de MySQL
			//En Java una clase no se carga a menos que sea necesario
			//Dado que el codigo JDBC nunca referencia al driver este nunca se cargaria
			
	public static Configurations configurations() throws classNotFoundException, SQLExpeption;
	
			Class.forName("com.mysql.cj.jdbc.Driver");
			String servidor = "jdbc:mysql://localhost:3306/libreria"; //url de conexión
			String username = "root"; //Usuario
			String password = "Duermebien25*"; //La contraseña de la BBDD
			
			Connection conexionBD = DriverManager.getConnection(servidor, username, password);
			Statement statement = conexionBD.createStatement();
			ResultSet clientes = statement.executeQuery("SELECT * FROM usuario");
			
			/*ArrayList<ClienteDTO> listaClientes = new ArrayList<>();
			
			while(clientes.next() != false) {
				RegistroDTO r = new Tipo(
						clientes.getString("customerName"),
						clientes.getString("phone"));
				listaClientes.add(r);
				}

			public static Object getInstance() {
				// TODO Auto-generated method stub
				return null;
			}*/
			conexionBD.close();
			//return listaClientes;
			}
	
}
