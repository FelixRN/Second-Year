package com.p02.view;

public class Usuario {

}
