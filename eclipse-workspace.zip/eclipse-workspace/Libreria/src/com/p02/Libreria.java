
package com.p02;


import java.sql.SQLException;


public class Libreria{

	public static void main(String[] args)throws ClassNotFoundException,
	SQLException {
		
		
		
	}
	
}
