/**
 * 
 */
/**
 * 
 */
module Libreria {
	requires java.sql;
}