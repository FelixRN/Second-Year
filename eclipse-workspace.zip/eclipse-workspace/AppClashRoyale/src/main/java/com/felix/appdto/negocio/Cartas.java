package com.felix.appdto.negocio;

import java.io.IOException;
import java.util.List;

import com.felix.appdto.modelo.ConsultaCartas;

public class Cartas {

    public List<String> verCartas(String nombre) throws IOException {
        ConsultaCartas consultaCartas = new ConsultaCartas();
        List<String> cartas = consultaCartas.consultaDeck(nombre);

        if (cartas.isEmpty()) {
            System.out.println("No se encontraron cartas para " + nombre);
        } else {
            System.out.println("Cartas de " + nombre + ":");
            for (String carta : cartas) {
                System.out.println("- " + carta);
            }
        }
        
        
		return cartas;
    }
}
