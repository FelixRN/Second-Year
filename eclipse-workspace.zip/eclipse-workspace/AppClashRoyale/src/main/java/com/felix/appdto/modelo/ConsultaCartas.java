package com.felix.appdto.modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConsultaCartas {

    public List<String> consultaDeck(String nombre) throws IOException {
        String path = Thread.currentThread().getContextClassLoader().getResource("Lista.txt").getPath();
        File f = new File(path);
        BufferedReader br = new BufferedReader(new FileReader(f));

        String linea;
        List<String> cartas = new ArrayList<>();

        while ((linea = br.readLine()) != null) {
            // Verificamos si la línea empieza con el nombre seguido de un "-"
            if (linea.startsWith(nombre + "-")) {
                String[] partes = linea.split("-");
                if (partes.length > 1) {
                    cartas.add(partes[1]); // añadimos la carta a la lista
                }
            }
        }

        br.close();
        return cartas;
    }
}



