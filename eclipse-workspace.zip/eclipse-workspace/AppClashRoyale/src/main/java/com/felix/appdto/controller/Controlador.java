package com.felix.appdto.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.felix.appdto.negocio.Cartas;

/**
 * Servlet implementation class Controlador
 */
@WebServlet("/Controlador")
public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controlador() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* De esta forma recuperamos el nombre del formularioy lo añadimos a una variable de tipo String */
		
			String nombre = request.getParameter("nombre");
			
			/*Instaciamos la clase de negocio Descuento */
			Cartas c = new Cartas();
			
			/*Llamamos al metodo que nos devuelve las cartas */
			List<String> listaCartas = c.verCartas(nombre);
			
			/* Setamos el atributo que le llegara a la vista*/
			request.setAttribute("cartas", listaCartas);
			request.setAttribute("nombre", nombre);
			/*Indicamos cual tiene que ser la vista a mostrar mediante el objeto RequestDispatcer*/
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/WEB-INF/cantidad.jsp");
			dispatcher.forward(request, response);
	}

}


