package com.example.demo.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

	@Controller
	public class InfoControler {

	@RequestMapping(value="/info")
	
	public String Hola() {
		return "info";
	}
}
