package primerEL;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Servlet implementation class ServletPrincipal
 */
@WebServlet("/obtenerpersona")
public class ServletPrincipal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletPrincipal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
Persona p = new Persona(25, "Felix");	
	request.setAttribute("persona", p);
	
	//Creamos una lista de tipo String y los seteamos a un atributo
	ArrayList<String> listaDeEquipos= new ArrayList();
	listaDeEquipos.add("Ferrari");
	listaDeEquipos.add("Aston Martin");
	listaDeEquipos.add("McLaren");
	request.setAttribute("listaEquipos", listaDeEquipos);
	
	//Creamos una lista de personas
	ArrayList<Persona> listaDePersonas = new ArrayList();
	listaDePersonas.add(new Persona(24, "Piastri"));
	listaDePersonas.add(new Persona(40, "Hamilton"));
	listaDePersonas.add(new Persona(28, "Verstappen"));
	request.setAttribute("listaPersonas", listaDePersonas);
	
	// Redirigimos a la vista que queremos mostrar
	RequestDispatcher dispatcher =
	getServletContext().getRequestDispatcher("/WEB-INF/Hola.jsp");
	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
}
