package controller;

import java.util.Date;

public class Hora {
	private Date time;
	
	public String getTime() {
		time = new Date();
		return time.toString();
	}
	
}
