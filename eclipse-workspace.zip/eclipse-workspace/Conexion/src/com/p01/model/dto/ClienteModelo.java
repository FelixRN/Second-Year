package com.p01.model.dto;

public class ClienteModelo {

}
