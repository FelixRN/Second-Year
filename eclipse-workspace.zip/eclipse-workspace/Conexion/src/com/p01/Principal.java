package com.p01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.p01.model.dto.ClienteDTO;

public class Principal {

	public static void main(String[] args)throws ClassNotFoundException,
	SQLException {
		
		//Con esta primera linea forzamos que cargue el driver de MySQL
		//En Java una clase no se carga a menos que sea necesario
		//Dado que el codigo JDBC nunca referencia al driver este nunca se cargaria
		Class.forName("com.mysql.cj.jdbc.Driver");
		String servidor = "jdbc:mysql://localhost:3306/classicmodels"; //url de conexión
		String username = "root"; //Usuario
		String password = "Duermebien25*"; //La contraseña de la BBDD
		
		Connection conexionBD = DriverManager.getConnection(servidor, username, password);
		Statement statement = conexionBD.createStatement();
		ResultSet clientes = statement.executeQuery("SELECT * FROM customers");
		
		ArrayList<ClienteDTO> listaClientes = new ArrayList<>();
		
		while(clientes.next() != false) {
			ClienteDTO c = new ClienteDTO(
					clientes.getString("customerName"),
					clientes.getString("phone"));
			listaClientes.add(c);
			}
		conexionBD.close();
		//return listaClientes;
		}
		
	}

