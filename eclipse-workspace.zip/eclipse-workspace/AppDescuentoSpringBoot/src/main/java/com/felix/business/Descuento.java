package com.felix.business;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.felix.model.IConsultaDatos;

@Component
public class Descuento implements IDescuento{
	@Autowired
	IConsultaDatos consultaDatos;
	@Override
	public int calularDescuento(String nombre) throws IOException {
	if(consultaDatos.consultaEdad(nombre) < 20) {
	return 5;
	}else {
	return 10;
	}
	}

}
