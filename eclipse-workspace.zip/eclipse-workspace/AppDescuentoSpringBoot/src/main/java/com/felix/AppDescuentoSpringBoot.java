package com.felix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppDescuentoSpringBoot {
	public static void main(String[] args) {
		SpringApplication.run(AppDescuentoSpringBoot.class, args);
	}
}
