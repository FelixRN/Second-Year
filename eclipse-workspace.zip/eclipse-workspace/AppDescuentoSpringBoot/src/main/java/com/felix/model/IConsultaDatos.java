package com.felix.model;

import java.io.IOException;

public interface IConsultaDatos {
	Integer consultaEdad(String nombre) throws IOException;
}
