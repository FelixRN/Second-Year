package com.felix.business;

import java.io.IOException;

public interface IDescuento {
	int calularDescuento(String nombre) throws IOException;
}
