package dao;

import java.util.ArrayList;

import dto.AsignaturaDTO;

public interface IAsignaturasDAO {
	ArrayList<AsignaturaDTO> obtenerTodas();
	ArrayList<AsignaturaDTO> buscarAsignaturas(String id, String nombre,String curso, int tasaMinima, int activo);
}
