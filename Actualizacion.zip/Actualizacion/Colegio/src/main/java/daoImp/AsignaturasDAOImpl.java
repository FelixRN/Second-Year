package daoImp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.IAsignaturaDAO;
import dto.AsignaturaDTO;
import utils.DBUtils;


public class AsignaturasDAOImpl implements IAsignaturasDAO{
	private static Logger logger = 
			LoggerFactory.getLogger(AsignaturasDAOImpl.class);

    @Override
    public ArrayList<AsignaturaDTO> buscarAsignaturas(String id, String nombre, String curso, int tasaMinima, int activo) {

        String sql = "SELECT id, nombre, curso, tasa, activo "
                   + "FROM asignaturas "
                   + "WHERE id LIKE ? AND nombre LIKE ? AND curso LIKE ? "
                   + "AND tasa >= ? AND activo = ?";

        ResultSet asignaturaResultSet = null;
		Connection connection = DBUtils.conexion();
        ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();

        try {
             PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, "%" + id + "%");
            ps.setString(2, "%" + nombre + "%");
            ps.setString(3, "%" + curso + "%");
            ps.setDouble(4, tasaMinima);
            ps.setInt(5, activo);

            logger.debug("Query a ejecutar: " + ps);

            asignaturaResultSet = ps.executeQuery();

            while (asignaturaResultSet.next()) {
            	AsignaturaDTO as = new AsignaturaDTO(asignaturaResultSet.getString("id"), asignaturaResultSet.getString("nombre"),  
            			asignaturaResultSet.getString("curso"), asignaturaResultSet.getDouble("tasa"), asignaturaResultSet.getInt("activo"));
            	listaAsignaturas.add(as);
            }
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listaAsignaturas;
    }

    @Override
    public ArrayList<AsignaturaDTO> obtenerTodas() {
    	
    	Connection connection = DBUtils.conexion();
		ResultSet asignaturas = null;
        ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();
        Statement statement;

        try {
        	statement = connection.createStatement();
			asignaturas = statement.executeQuery("SELECT * FROM asignaturas");

            while (asignaturas.next()) {
                AsignaturaDTO as = new AsignaturaDTO(asignaturas.getString("id"), asignaturas.getString("nombre"), asignaturas.getString("curso"));
                logger.debug("Contenido de asignatura" + as.getNombre() + " " + as.getId());
                listaAsignaturas.add(as);
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listaAsignaturas;
    }
}
