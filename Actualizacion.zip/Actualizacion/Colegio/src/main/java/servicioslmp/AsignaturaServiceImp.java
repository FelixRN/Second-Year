package servicioslmp;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.IAsignaturasDAO;
import dto.AsignaturaDTO;
import servicios.IAsignaturasService;

public class AsignaturaServiceImp implements IAsignaturasService{

	@Override
	public ArrayList<AsignaturaDTO> obtenerTodas() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<AsignaturaDTO> buscarAsignaturas(String id, String nombre, String curso, int tasaMinima,
			int activo) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.buscarAsignaturas(id, nombre, curso, tasaMinima, activo);
	}

}
