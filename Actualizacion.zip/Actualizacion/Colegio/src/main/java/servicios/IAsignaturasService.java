package servicios;

import java.sql.SQLException;
import java.util.ArrayList;

import dto.AsignaturaDTO;


public interface IAsignaturasService {
	
	public ArrayList<AsignaturaDTO> obtenerTodas() throws SQLException;
	public ArrayList<AsignaturaDTO> buscarAsignaturas(String id, String nombre,String curso, int tasaMinima, int activo);
}
