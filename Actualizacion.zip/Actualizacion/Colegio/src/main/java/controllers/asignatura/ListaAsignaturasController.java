package controllers.asignatura;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.IAsignaturasService;
import servicioslmp.AsignaturaServiceImp;

import java.io.IOException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dto.AlumnoDTO;
import dto.AsignaturaDTO;

/**
 * Servlet implementation class ListaAsignaturasController
 */
@WebServlet("/listarAsignaturas")
public class ListaAsignaturasController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(ListaAsignaturasController.class);

    public ListaAsignaturasController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");

        String id = request.getParameter("id") != null ? request.getParameter("id") : "";
        String nombre = request.getParameter("nombre") != null ? request.getParameter("nombre") : "";
        String curso = request.getParameter("curso") != null ? request.getParameter("curso") : "";

        double tasaMin = 0.0;
        try {
            tasaMin = Double.parseDouble(request.getParameter("tasaMin"));
        } catch (Exception e) {
            tasaMin = 0.0;
        }

        int activo = Integer.parseInt(request.getParameter("activo"));
        
        IAsignaturasService as = new AsignaturaServiceImp();
        ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();
        
        listaAsignatura = as.buscarAsignaturas(id, nombre, curso, tasaMin, activo);
        request.setAttribute("listaAsignaturas", listaAsignatura);
        RequestDispatcher d = getServletContext().getRequestDispatcher("/WEB-INF/listarAsignaturas.jsp");
        d.forward(request, response);
	}

}
