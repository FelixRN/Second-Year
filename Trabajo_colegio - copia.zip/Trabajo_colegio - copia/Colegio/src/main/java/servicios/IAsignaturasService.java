package servicios;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.IAsignaturasDAO;
import dto.AsignaturaDTO;


public interface IAsignaturasService {
	
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() throws SQLException;
	public ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, double tasa, int activo);
	public int insertarAsignatura(String id, String nombre, String curso, double tasa, int activo);
	public int actualizarAsignatura(String id, String nombre, String curso, double tasa, int activo);
	public int borrarAsignatura(String id);
	};

