package daoImp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.IAsignaturasDAO;
import dto.AlumnoDTO;
import dto.AsignaturaDTO;
import utils.DBUtils;


public class AsignaturasDAOImpl implements IAsignaturasDAO{
	private static Logger logger = 
			LoggerFactory.getLogger(AsignaturasDAOImpl.class);
	
@Override
    public ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(
    		String id, String nombre, String curso, double tasa, int activo){

	String sql = "SELECT id, nombre, curso, tasa, activo "
	           + "FROM asignaturas "
	           + "WHERE id LIKE ? AND nombre LIKE ? AND curso LIKE ? AND tasa >= ? AND activo = ?";
        
        ResultSet asignaturaResultSet = null;
		Connection connection = DBUtils.conexion();
        ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();

        try {
             PreparedStatement ps = connection.prepareStatement(sql);
            
            ps.setString(1, "%" + id + "%");
 			ps.setString(2, "%" + nombre + "%");
 			ps.setString(3, "%" + curso + "%");
 			ps.setDouble(4, tasa);
 			ps.setInt(5, activo);

 			logger.debug("Query a ejecutar: " + ps);

 			asignaturaResultSet = ps.executeQuery();

            while (asignaturaResultSet.next()) {
                AsignaturaDTO as = new AsignaturaDTO(asignaturaResultSet.getInt(1),
                        asignaturaResultSet.getString(2),
                        asignaturaResultSet.getInt(3),
                        asignaturaResultSet.getDouble(4),
                        asignaturaResultSet.getInt(5));
     			logger.debug(as.toString());

                listaAsignaturas.add(as);
            }
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listaAsignaturas;
    }

	@Override
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() {
		Connection connection = DBUtils.conexion();
		ResultSet asignaturas = null;
		ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();
		Statement statement;

		try {

			statement = connection.createStatement();
			asignaturas = statement.executeQuery("SELECT * FROM alumnos");

			while (asignaturas.next()) {
				AsignaturaDTO a = new AsignaturaDTO(asignaturas.getInt(1), asignaturas.getString(2), asignaturas.getInt(3));
				logger.debug("Contenido de alumno " + a.getNombre() + " " + a.getId());
				listaAsignaturas.add(a);
			}
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaAsignaturas;
	}

	@Override
	public int insertarAsignatura(String id, String nombre, String curso, double tasa, int activo) {
		String sql = "INSERT INTO asignaturas (id, nombre, curso, tasa, activo) VALUES (?, ?, ?, ?, ?)";
		logger.debug("Query a ejecutar: " + sql);
		PreparedStatement ps = null;
		int resultado = 0;
		try {
			Connection connection = DBUtils.conexion();
			ps = connection.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, nombre);
			ps.setString(3, curso);
			ps.setDouble(4, tasa);
			ps.setInt(5, activo);
			logger.debug("Query a ejecutar: " + ps);
			resultado = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultado;
	}

	@Override
	public int actualizarAsignatura(String id, String nombre, String curso, double tasa, int activo) {
		
		String sql = "UPDATE asignaturas SET nombre = ?, curso = ?, tasa = ? , activo = ? "
				+ "WHERE id = ? ";
		logger.debug("Query para actualizar: " + sql);
		PreparedStatement ps = null;
		int resultado = 0;
		try {
			Connection connection = DBUtils.conexion();
			ps = connection.prepareStatement(sql);
			ps.setString(1, nombre);
			ps.setString(2, curso);
			ps.setDouble(3, tasa);
			ps.setInt(4, activo);
			ps.setString(5, id);
			logger.debug("ActualizarAsignatura:" + ps);
			resultado = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int borrarAsignatura(String id) {
		
		String sql = "UPDATE asignaturas SET activo = 0 " + "WHERE id = ? ";
		Connection connection = DBUtils.conexion();
		PreparedStatement ps;
		Integer resultado = 0;
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, id);
			logger.debug("Query a ejecutar: " + ps);
			resultado = ps.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultado;
	}


   
}
