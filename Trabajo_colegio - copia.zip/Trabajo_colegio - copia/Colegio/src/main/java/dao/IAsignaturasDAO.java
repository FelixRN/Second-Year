package dao;

import java.util.ArrayList;

import dto.AsignaturaDTO;

public interface IAsignaturasDAO {
	ArrayList<AsignaturaDTO> obtenerTodasAsignaturas();
	int borrarAsignatura(String id);
	ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, double tasa, int activo);
	int insertarAsignatura(String id, String nombre, String curso, double tasa, int activo);
	int actualizarAsignatura(String id, String nombre, String curso, double tasa, int activo);
}
