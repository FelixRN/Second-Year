package controllers.asignaturas;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.IAlumnosService;
import servicios.IAsignaturasService;
import servicioslmp.AlumnosServiceImp;
import servicioslmp.AsignaturaServiceImp;
import utils.DesplegableUtils;

import java.io.IOException;
import java.util.ArrayList;

import dao.IDesplegableDAO;
import daoImp.DesplegableDAOImp;
import dto.DesplegableDTO;


@WebServlet("/asignaturas/insertarAsignatura")
public class InsertarAsignaturasController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InsertarAsignaturasController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DesplegableUtils.recuperarDesplegableMunicipios(request);
		
		RequestDispatcher d =getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/insertarAsignatura.jsp");
		d.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String nombre = request.getParameter("nombre");
		String curso = request.getParameter("curso");
		String tasa = request.getParameter("tasa");
		String activo = request.getParameter("activo");

		IAsignaturasService a = new AsignaturaServiceImp();
		
		Integer resultado = a.insertarAsignatura(id, nombre, curso, Double.parseDouble(tasa), Integer.parseInt(activo));
		request.setAttribute("resultado", resultado);

		recuperarDesplegableMunicipios(request);

		RequestDispatcher d =
				getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/insertarAsignatura.jsp");
		d.forward(request, response);
	}
	
	private void recuperarDesplegableMunicipios(HttpServletRequest request) {
		IDesplegableDAO desplegableMunicipios = new DesplegableDAOImp();
		ArrayList<DesplegableDTO> listaMunicipios =desplegableMunicipios.desplegableMunicipios();
		request.setAttribute("desplegableMunicipios", listaMunicipios);
	}

}
