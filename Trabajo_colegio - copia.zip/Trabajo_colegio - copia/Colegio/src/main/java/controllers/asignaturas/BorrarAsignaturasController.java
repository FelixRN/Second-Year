package controllers.asignaturas;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.IAsignaturasService;
import servicioslmp.AsignaturaServiceImp;

import java.io.IOException;


@WebServlet("/asignaturas/borrarAsignatura")
public class BorrarAsignaturasController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public BorrarAsignaturasController() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		
		IAsignaturasService a = new AsignaturaServiceImp();
		a.borrarAsignatura(id);
		
		RequestDispatcher d = getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/borrarAsignaturas.jsp");
        d.forward(request, response);
	}

}
