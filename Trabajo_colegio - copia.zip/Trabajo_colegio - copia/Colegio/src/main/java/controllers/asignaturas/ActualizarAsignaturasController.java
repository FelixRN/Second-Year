package controllers.asignaturas;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.IAlumnosService;
import servicios.IAsignaturasService;
import servicioslmp.AlumnosServiceImp;
import servicioslmp.AsignaturaServiceImp;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import daoImp.AsignaturasDAOImpl;

/**
 * Servlet implementation class ActualizarAsignaturasController
 */
@WebServlet("/asignaturas/actualizarAsignatura")
public class ActualizarAsignaturasController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = 
			LoggerFactory.getLogger(ActualizarAsignaturasController.class);
       
  
    public ActualizarAsignaturasController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		logger.debug("Actualizar controller 1: " + id);
	    String nombre = request.getParameter("nombre");
		logger.debug("Actualizar controller 2: " + nombre);

	    String curso = request.getParameter("curso");
	    String tasa = request.getParameter("tasa");
	    String activo = request.getParameter("activo");
	    
		if(tasa == null || tasa.trim().isEmpty())
			tasa = "0";
		
		if(activo != null)
			activo = "1";
		else
			activo = "0";
        
	    
	    IAsignaturasService a = new AsignaturaServiceImp();
	    
	    a.actualizarAsignatura(id, nombre, curso, Double.parseDouble(tasa), Integer.parseInt(activo));
	    logger.debug("Final " + a.toString());
        RequestDispatcher d = getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/actualizarAsignaturas.jsp");
        d.forward(request, response);
	}

}
