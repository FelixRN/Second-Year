package servicioslmp;

import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.IAlumnosDAO;
import dao.IAsignaturasDAO;
import daoImp.AlumnosDAOImpl;
import daoImp.AsignaturasDAOImpl;
import dto.AsignaturaDTO;
import servicios.IAsignaturasService;

public class AsignaturaServiceImp implements IAsignaturasService{
	private static Logger logger = 
			LoggerFactory.getLogger(AsignaturaServiceImp.class);

	@Override
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, double tasa, int activo) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.obtenerAsignaturaPorIdNombreCurso(id, nombre, curso, tasa, activo);
	}
	
	@Override
	public int insertarAsignatura(String id, String nombre, String curso, double tasa, int activo) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.insertarAsignatura(id, nombre, curso, tasa, activo);
	}

	@Override
	public int actualizarAsignatura(String id, String nombre, String curso, double tasa ,int activo) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.actualizarAsignatura(id, nombre, curso, tasa, activo);
	}

	@Override
	public int borrarAsignatura(String id) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.borrarAsignatura(id);
	}

}
