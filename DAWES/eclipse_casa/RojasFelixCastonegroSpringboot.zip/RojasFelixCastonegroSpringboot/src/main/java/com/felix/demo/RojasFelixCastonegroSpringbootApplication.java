package com.felix.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class RojasFelixCastonegroSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RojasFelixCastonegroSpringbootApplication.class, args);
	}

}
