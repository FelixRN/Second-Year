package servicioslmp;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.IAsignaturasDAO;
import daoImp.AsignaturasDAOImpl;
import dto.AsignaturaDTO;
import servicios.IAsignaturasService;

public class AsignaturaServiceImp implements IAsignaturasService{

	@Override
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, String tasa, int activo) {
		IAsignaturasDAO asignaturas = new AsignaturasDAOImpl();
		return asignaturas.obtenerAsignaturaPorIdNombreCurso(id, nombre, curso, tasa, activo);
	}

}
