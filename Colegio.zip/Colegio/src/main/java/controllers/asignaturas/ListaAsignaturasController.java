package controllers.asignaturas;

import java.io.IOException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dto.AsignaturaDTO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.IAsignaturasService;
import servicioslmp.AsignaturaServiceImp;

@WebServlet("/asignaturas/listadoAsignaturas")
public class ListaAsignaturasController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(ListaAsignaturasController.class);

    public ListaAsignaturasController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher d =
				getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/listadoAsignaturas.jsp");
				d.forward(request, response);	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*request.setCharacterEncoding("UTF-8");*/
		String id = request.getParameter("id");
		String nombre = request.getParameter("nombre");
		String curso = request.getParameter("curso");
		String tasa = request.getParameter("tasa");
		String activo = request.getParameter("activo");
		
		logger.info(activo);
		
		if(activo != null)
        	activo = "1";
        else
        	activo = "0";
		
		IAsignaturasService as = new AsignaturaServiceImp();
        ArrayList<AsignaturaDTO> listaAsignaturas = new ArrayList<>();
        
        listaAsignaturas = as.obtenerAsignaturaPorIdNombreCurso(id, nombre, curso, tasa,Integer.parseInt(activo));
        
        request.setAttribute("lista", listaAsignaturas);
        RequestDispatcher d = getServletContext().getRequestDispatcher("/WEB-INF/vistas/asignaturas/listadoAsignaturas.jsp");
        d.forward(request, response);
	}

}
