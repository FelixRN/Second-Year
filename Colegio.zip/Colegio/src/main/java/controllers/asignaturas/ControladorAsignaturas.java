package controllers.asignaturas;

import java.io.IOException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.IAsignaturasDAO;
import daoImp.AsignaturasDAOImpl;
import dto.AsignaturaDTO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/asignatura/obtenertodasasignaturas")
public class ControladorAsignaturas extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(ControladorAsignaturas.class);

    public ControladorAsignaturas() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IAsignaturasDAO asignaturasDao = new AsignaturasDAOImpl();
		ArrayList<AsignaturaDTO> listaAsignaturas =
		asignaturasDao.obtenerTodasAsignaturas();
		request.setAttribute("listaAsignaturas", listaAsignaturas);
		RequestDispatcher d =
		getServletContext().getRequestDispatcher("/WEB-INF/listadoAsignaturas.jsp");
		d.forward(request, response);	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
