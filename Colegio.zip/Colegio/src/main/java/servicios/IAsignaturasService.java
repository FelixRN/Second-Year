package servicios;

import java.sql.SQLException;
import java.util.ArrayList;

import dto.AsignaturaDTO;


public interface IAsignaturasService {
	
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() throws SQLException;
	public ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, String tasa, int activo);
}
