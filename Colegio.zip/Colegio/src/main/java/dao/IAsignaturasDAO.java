package dao;

import java.util.ArrayList;

import dto.AsignaturaDTO;

public interface IAsignaturasDAO {
	ArrayList<AsignaturaDTO> obtenerTodasAsignaturas();
	ArrayList<AsignaturaDTO> obtenerAsignaturaPorIdNombreCurso(String id, String nombre, String curso, String tasa, int activo);
	int insertarAsignatura(int id, String nombre, int curso, int tasaMinima, int activo);
	int actualizarAsignatura(int id, String nombre, int curso, int tasaMinima, int activo);
	int borrarAsignatura(String id);
	
}
